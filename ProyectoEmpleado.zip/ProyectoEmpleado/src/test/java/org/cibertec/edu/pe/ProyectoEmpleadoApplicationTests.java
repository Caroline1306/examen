package org.cibertec.edu.pe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoEmpleadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
