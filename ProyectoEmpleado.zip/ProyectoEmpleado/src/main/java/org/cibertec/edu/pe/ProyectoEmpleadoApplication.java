package org.cibertec.edu.pe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoEmpleadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoEmpleadoApplication.class, args);
	}

}
