package org.cibertec.edu.pe.interfaceService;
import java.util.List;

import org.cibertec.edu.pe.modelo.empleados;



public interface IEmpleadosService {

	public List<empleados> Listado();
	
}
